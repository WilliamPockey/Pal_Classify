# import os

# # 获取当前.py文件所在文件夹路径
# folder_path = os.path.dirname(os.path.abspath(__file__))
# print("当前文件夹路径：", folder_path)

# # 创建一个txt文件来保存路径
# output_file = open('image_paths.txt', 'w')

# # 遍历当前文件夹内所有文件
# for file_name in os.listdir(folder_path):
#     # 判断文件是否为图片文件
#     if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
#         # 获取图片文件的绝对路径
#         image_path = os.path.abspath(os.path.join(folder_path, file_name))
#         print(image_path + ' 9')
#         # 将路径写入txt文件
#         output_file.write(image_path + '\n')

# # 关闭txt文件
# output_file.close()
import os

def write_image_paths(folder_path, output_file, folder_index):
    # 遍历当前文件夹内所有文件
    for file_name in os.listdir(folder_path):

        # 获取文件的绝对路径
        file_path = os.path.abspath(os.path.join(folder_path, file_name))
        
        if os.path.isdir(file_path):
            # 如果是子文件夹，递归调用write_image_paths函数
            write_image_paths(file_path, output_file, folder_index + 1)
        elif file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
            # 如果是图片文件，将路径写入txt文件
            image_path = file_path + '\n'
            print(image_path)
            output_file.write(image_path)

# 获取当前.py文件所在文件夹路径
folder_path = os.path.dirname(os.path.abspath(__file__))
print("当前文件夹路径：", folder_path)

# 创建一个txt文件来保存路径
output_file = open('D:\\desk\\pal\\train.txt', 'w')

# 调用函数写入图片路径
write_image_paths(folder_path, output_file, 0)

# 关闭txt文件
output_file.close()

