# import os

# # 指定文件夹路径
# folder_path = os.path.dirname(os.path.abspath(__file__))


# # 获取文件夹内所有文件名
# files = os.listdir(folder_path)

# # 初始化计数器
# count = 1

# # 遍历文件夹内的文件
# for file in files:
#     if file.endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):

#         # 生成新的文件名
#         new_name = str(count).zfill(3) + '.' + file.split('.')[-1]
        
#         # 重命名文件
#         os.rename(os.path.join(folder_path, file), os.path.join(folder_path, new_name))
        
#         # 更新计数器
#         count += 1

# print('照片文件已重命名完成。')


import os

def rename_photos(folder_path, count):
    # 获取文件夹内所有文件名
    files = os.listdir(folder_path)

    # 遍历文件夹内的文件
    for file in files:
        file_path = os.path.join(folder_path, file)
        if os.path.isdir(file_path):
            # 如果是子文件夹，则递归调用函数
            rename_photos(file_path, count)
        elif file.endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
            # 生成新的文件名
            new_name = str(count).zfill(3) + '.' + file.split('.')[-1]
            
            # 重命名文件
            os.rename(file_path, os.path.join(folder_path, new_name))
            
            # 更新计数器
            count += 1

# 指定文件夹路径
folder_path = os.path.dirname(os.path.abspath(__file__))

# 初始化计数器
count = 1

# 调用函数重命名文件夹下所有子文件夹中的图片文件
rename_photos(folder_path, count)

print('照片文件已重命名完成。')
